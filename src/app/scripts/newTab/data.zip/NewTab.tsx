import * as React from "react";
// import { Provider, Flex, Text, Button, Header } from "@fluentui/react-northstar";
import TeamsBaseComponent, { ITeamsBaseComponentState } from "msteams-react-base-component";
import { BotDeclaration, MessageExtensionDeclaration, PreventIframe } from "express-msteams-host";
import { DialogSet, DialogState } from "botbuilder-dialogs";
import { StatePropertyAccessor, CardFactory, TurnContext, MemoryStorage, ConversationState, ActivityTypes, TeamsActivityHandler, TaskModuleRequest } from "botbuilder";


import * as microsoftTeams from "@microsoft/teams-js";
import Choices from "./Choices";
// import { List, Image } from '@fluentui/react-northstar'
import { List, Button, Flex, Image, Text, Provider, Header } from '@fluentui/react-northstar'
import { DownloadIcon, MoreIcon } from '@fluentui/react-icons-northstar'
// import Card from 'react-bootstrap/Card'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
import Container from 'react-bootstrap/Container'
import { Dropdown } from '@fluentui/react-northstar'
import { TextArea } from '@fluentui/react-northstar'
import { Avatar } from '@fluentui/react-northstar'

import Table from 'react-bootstrap/Table'
import Card from 'react-bootstrap/Card'

import "../thankZTab/styles.css";

import ReceiverCard from "../../thankZBot/receiverCard/receiverCard";
import { GetBadges } from './data';


// Import Components
// import Badges  from './badge';

/**
 * State for the thankZTabTab React component
 */
export interface INewTabState extends ITeamsBaseComponentState {
    entityId?: string;
}

/**
 * Properties for the thankZTabTab React component
 */
export interface INewTabTabProps {

}

const badges = [
    {
        id: '1',
        name: 'Thank You',
        images: 'https://raw.githubusercontent.com/MicrosoftDocs/OfficeDocs-SkypeForBusiness/live/Teams/downloads/praise-app/default-set/thank-you-badge.png'

    },
    {
        id: '2',
        name: 'Achiever',
        images: 'https://raw.githubusercontent.com/MicrosoftDocs/OfficeDocs-SkypeForBusiness/live/Teams/downloads/praise-app/default-set/achiever-badge.png'

    },
    {
        id: '3',
        name: 'Kind Heart',
        images: 'https://raw.githubusercontent.com/MicrosoftDocs/OfficeDocs-SkypeForBusiness/live/Teams/downloads/praise-app/default-set/kind-heart-badge.png'

    },
    {
        id: '4',
        name: 'Team Player',
        images: 'https://raw.githubusercontent.com/MicrosoftDocs/OfficeDocs-SkypeForBusiness/live/Teams/downloads/praise-app/default-set/team-player-badge.png'

    },
    {
        id: '5',
        name: 'Leadership',
        images: 'https://raw.githubusercontent.com/MicrosoftDocs/OfficeDocs-SkypeForBusiness/live/Teams/downloads/praise-app/default-set/leadership-badge.png'

    },
    {
        id: '6',
        name: 'Coach',
        images: 'https://raw.githubusercontent.com/MicrosoftDocs/OfficeDocs-SkypeForBusiness/live/Teams/downloads/praise-app/default-set/coach-badge.png'

    }
]


const items = [
    {
      key: 'Thank You',
      media: <Image src="https://raw.githubusercontent.com/MicrosoftDocs/OfficeDocs-SkypeForBusiness/live/Teams/downloads/praise-app/default-set/thank-you-badge.png" avatar />,
      header: 'Thank You',
      content: 'Add details about the badge',
    },
    {
      key: 'Achiever',
      media: <Image src="https://raw.githubusercontent.com/MicrosoftDocs/OfficeDocs-SkypeForBusiness/live/Teams/downloads/praise-app/default-set/achiever-badge.png" avatar />,
      header: 'Achiever',
      content: 'Add details about the badge',
    },
    {
      key: 'Kind Heart',
      media: <Image src="https://raw.githubusercontent.com/MicrosoftDocs/OfficeDocs-SkypeForBusiness/live/Teams/downloads/praise-app/default-set/kind-heart-badge.png" avatar />,
      header: 'Kind Heart',
      content: 'Add details about the badge',
    }
  ]

  const items2 = [
    {
        key: 'Team Player',
        media: "",
        header: 'Team Player',
        content: 'Add details about the badge',
      },
      {
        key: 'Leadership',
        media: <Image src="https://raw.githubusercontent.com/MicrosoftDocs/OfficeDocs-SkypeForBusiness/live/Teams/downloads/praise-app/default-set/leadership-badge.png" avatar />,
        header: 'Leadership',
        content: 'Add details about the badge',
      },
      {
        key: 'Coach',
        media: <Image src="https://raw.githubusercontent.com/MicrosoftDocs/OfficeDocs-SkypeForBusiness/live/Teams/downloads/praise-app/default-set/coach-badge.png" avatar />,
        header: 'Coach',
        content: 'Add details about the badge',
      },
      {
        // key: 'Coach',
        // media: <Image src="https://raw.githubusercontent.com/MicrosoftDocs/OfficeDocs-SkypeForBusiness/live/Teams/downloads/praise-app/default-set/coach-badge.png" avatar />,
        // header: 'Coach',
        // content: 'Add details about the badge',
      }
  ]


  const inputItems = [
    {
      header: 'Pavithra',
      image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTlpS8SkotGxHLBiUB1KxsUQ_GacEoWfSL_ig&usqp=CAU',
      content: 'Software Engineer',
    },
    {
      header: 'Alex Wilber',
      image: 'https://images.unsplash.com/photo-1511367461989-f85a21fda167?ixid=MXwxMjA3fDB8MHxzZWFyY2h8Mnx8cHJvZmlsZXxlbnwwfHwwfA%3D%3D&ixlib=rb-1.2.1&w=1000&q=80',
      content: 'UX Designer 2',
    },
    {
      header: 'Debra Berger',
      image: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500',
      content: 'Principal Software Engineering Manager',
    },
    {
      header: 'Irvin Sayers',
      image: 'https://i.pinimg.com/564x/d9/56/9b/d9569bbed4393e2ceb1af7ba64fdf86a.jpg',
      content: 'Technology Consultant',
    },
    {
      header: `Isaiah Langer`,
      image: 'https://widgetwhats.com/app/uploads/2019/11/free-profile-photo-whatsapp-4.png',
      content: 'Software Engineer 2',
    },
    {
      header: 'Joni Sherman',
      image: 'https://images.unsplash.com/photo-1529665253569-6d01c0eaf7b6?ixid=MXwxMjA3fDB8MHxzZWFyY2h8M3x8cHJvZmlsZXxlbnwwfHwwfA%3D%3D&ixlib=rb-1.2.1&w=1000&q=80',
      content: 'Boss',
    },
    {
      header: 'Lee Gu',
      image: 'https://images.unsplash.com/photo-1529665253569-6d01c0eaf7b6?ixid=MXwxMjA3fDB8MHxzZWFyY2h8M3x8cHJvZmlsZXxlbnwwfHwwfA%3D%3D&ixlib=rb-1.2.1&w=1000&q=80',
      content: 'Senior Computer Scientist',
    },
    {
      header: 'Pradeep Gupta',
      image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTq2hiMM4LY3J-nPX9QFO0URL2siUWeJP-t-A&usqp=CAU',
      content: 'Partner Software Engineer',
    },
    {
      header: 'Selina Kyle',
      image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTlpS8SkotGxHLBiUB1KxsUQ_GacEoWfSL_ig&usqp=CAU',
      content: 'Graphic Designer',
    },
  ]

/**
 * Implementation of the ThankZ content page
 */
export class NewTab extends TeamsBaseComponent<any, any> {

    public constructor(props, public adapter) {
        super(props);
        this.state = {
            badges: [],
            status: true,
            sImage: '',
            sName: '',
            sId: '',
            selectedBadge: 0,
            receiverName: '',
            receiverImage: '',
            comments: '',
            values: []
        }
        // console.log(this.state);
    }

    badgesToArray () {
        let some = [{}]
        this.state.values.map((data,key) => {
            // data.filter(value => Object.keys(value).length !== 0);
            some.push({"id": data.ID,"key":data.Title,"header": data.Title,"images":<Image src={data.Image} avatar />,"content":data.content})
            // this.setState({
            //     badges: some,
            // })    
        })
        console.log(some);
        return some;
    }



    stateSet() {
     const newValue =  this.badgesToArray();

     this.setState({
        values: newValue,
     })

     console.log(this.state);
    }

    public async componentWillMount() {
        this.updateTheme(this.getQueryVariable("theme"));

        let badge = await GetBadges();
        console.log(badge);
        await this.setState({
            values: badge,
        });
        this.stateSet();
        if (await this.inTeams()) {
            microsoftTeams.initialize();
            microsoftTeams.registerOnThemeChangeHandler(this.updateTheme);
            microsoftTeams.getContext((context) => {
                microsoftTeams.appInitialization.notifySuccess();
                this.setState({
                    entityId: context.entityId
                });
                this.updateTheme(context.theme);
            });
        } else {
            this.setState({
                entityId: "This is not hosted in Microsoft Teams"
            });
        }
    }

    /**
     * The render() method to create the UI of the tab
     */
    public render() {

        const clickHandler = (card) => {
            alert(card.name);
            this.setState({
                status: false,
                sImage: card.images,
                sName: card.name,
            })
        }

        const submitHandler = () => {
            this.setState({
                status: true,
                receiverName: '',
                comments: ''
            })
        }

        const handle1 = (index) => {
            // this.setState({
            //     status: true
            // })
            const value = this.state.values[index];
            console.log(value);
            console.log(value.key)
            console.log(value.header)
            console.log(value.images.props.src)
            this.setState({
                sImage: value.images.props.src,
                sName: value.header,
                status: false
            })
        }

        const handle2 = (index) => {
            this.setState({
                status: true
            })
            const value = items[index];
            console.log(value);
        }

        const handleChange = (event, value) => {
            console.log(value)
            console.log(value.value[0].header)
            console.log(event)
            this.setState({
                receiverName: value.value[0].header,
                receiverImage: value.value[0].image
            })

        }

        const getA11ySelectionMessage = {
            onAdd: item => `${item.header} has been removed.`,
            onRemove: item => `${item.header} has been removed.`,
        }

        const handleTextChange = (event, value) => {
            console.log(value.value);
            // console.log(event);
            // console.log(event.value);
            this.setState({
                comments: value.value
            })
        }


        const callHandler = () => {

            microsoftTeams.initialize();
            microsoftTeams.tasks.submitTask("data", process.env.MICROSOFT_APP_ID)
            // let address: any =
            // {
            //     user:
            //     {
            //         id:
            //             '29:1QO2xPuh-Q1Rj47riIllSFmNpjXHTIcKqI--YX0j7kgxuztXUOm24NMWU7Oynlo8YVXXfjNWlmJ5Tl_zh9CSrrg',
            //         name: 'Pavithrra Sekar',
            //         aadObjectId: 'd9866e2f-05a0-4d03-b2a5-eb00b46ab9eb'
            //     },
            //     bot:
            //     {
            //         id: '28:5efb52f6-ed8b-4af0-b7b4-8eb44cb1e8a8',
            //         name: 'iAppreciate'
            //     },
            //     conversation:
            //     {
            //         conversationType: 'personal',
            //         tenantId: '83a8ed06-53b4-4ea7-95e7-1fcfb93f84bc',
            //         id:
            //             'a:1SVLrfdF5m78OMkEtO14tY3r7bHm3KjoDM5aD-Ct1hVWhTM3BJna7q75b3mg5fLt_Zw3GIJX4hzM6pXbNZhW2-Qaa1zgEPyB86rZv_xlzRAzAUKNpKwgYBZcE2MB7iihV'
            //     },
            //     channelId: 'msteams',
            //     serviceUrl: 'https://smba.trafficmanager.net/apac/'
            // }
 
            // this.adapter.continueConversation(address, async turnContext => {
            //     // If you encounter permission-related errors when sending this message, see
            //     await turnContext.sendActivity({ attachments: [ReceiverCard] })
            // });            

            console.log('called');

        }

        

        
        // console.log(some);

        return (
            <Provider theme={this.state.theme}>
                {/* {badgesToArray()} */}

                { 
                    (this.state.status === true )
                    ? <div style={{ width: '109%', margin: '10px',}}> 
                        {/* {nameList}  */}

                        <h4 className="text-center">Select a badge</h4>

                        <List selectable items={this.state.values} horizontal
                            styles={{ height: '4rem',width: '800px'}}
                            // className="badgesrow badges li"
                            defaultSelectedIndex={0}
                            selectedIndex={this.state.selectedBadge}
                            onSelectedIndexChange={(e, newProps: any) => {
                                handle1(newProps.selectedIndex)
                                console.log(this.state)
                            }} />

                        <List selectable items={items2} horizontal
                            styles={{ height: '4rem', marginTop: '10px' }}
                            // className="badgesrow badges li"
                            defaultSelectedIndex={0}
                            selectedIndex={this.state.selectedBadge}
                            onSelectedIndexChange={(e, newProps: any) => {
                                handle2(newProps.selectedIndex)
                                console.log(this.state)
                            }} />

                    </div> 
                    : <div>
                        <Container fluid="md">

                            <div style={{ margin: '-36px' }}>

                                {/* <h4 style={{ marginLeft: '55px' }}>Add details</h4> */}
                                <Table>
                                    <tr>
                                        <td className="float-left">
                                            <div style={{ margin: '10px 50px 50px' }}>
                                                <tr>
                                                    <td>
                                                        <h5 style={{ marginTop: '30px' }}>Receiver</h5>
                                                        <Dropdown
                                                            style = {{ height: '40px'}}
                                                            multiple
                                                            search
                                                            items={inputItems}
                                                            placeholder="Receiver"
                                                            onChange={handleChange}
                                                            getA11ySelectionMessage={getA11ySelectionMessage}
                                                            noResultsMessage="We couldn't find any matches."
                                                        />
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td>
                                                        <h5 className="mt-2">Manager</h5>
                                                        <Dropdown
                                                            multiple
                                                            search
                                                            items={inputItems}
                                                            placeholder="Managers"
                                                            getA11ySelectionMessage={getA11ySelectionMessage}
                                                            noResultsMessage="We couldn't find any matches."
                                                        />

                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td>
                                                        <h5 className="mt-2">Peers</h5>
                                                        <Dropdown
                                                            multiple
                                                            search
                                                            items={inputItems}
                                                            placeholder="Peers"
                                                            getA11ySelectionMessage={getA11ySelectionMessage}
                                                            noResultsMessage="We couldn't find any matches."
                                                        />

                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td>
                                                            <TextArea fluid onChange={handleTextChange} styles={{ marginTop: '27px'}} resize="both" placeholder="Add comments..." />
                                                    </td>
                                                </tr>
                                                

                                            </div>
                                        </td>
                                        <td className="float-right" style={{ backgroundColor: 'aliceblue', paddingBottom: '26px', paddingLeft: '13px', paddingRight: '145px' }}>
                                            

                                            <Card>
                                                <Card.Body>

                                                    <tr>

                                                        <td>
                                                                <div>
                                                                    <h5>To: {this.state.receiverName}</h5>
                                                                </div>

                                                        </td>

                                                        <td>
                                                            <h5>{ this.state.sName }</h5>
                                                        </td>

                                                    </tr>

                                                    

                                                    <tr>
                                                        <Card>
                                                            <Card.Img variant="top" src={this.state.sImage} style={{ height: '10rem', }}/>
                                                            
                                                        </Card>
                                                    </tr>


                                                    <tr>
                                                        <h5>{this.state.comments}</h5>
                                                    </tr>

                                                    
                                                </Card.Body>
                                            </Card>

                                            <tr>
                                                        <td>
                                                            <Button content="Secondary" onClick={() =>  submitHandler() }>Back</Button>
                                                        </td>

                                                        <td>
                                                            <Button content="Primary" onClick={() => callHandler()}>Send</Button>
                                                        </td>
                                            </tr>

                                            
                                            
                                            
                                            {/* <img style={{ height: '8rem', marginBottom: '150px'}} src={this.state.sImage} /> */}
                                            
                                        </td>
                                    </tr>

                                </Table>

                            </div>

                        </Container> 
                    </div> 
                }
                {/* {nameList} */}
                
            </Provider>
        );
    }
}
