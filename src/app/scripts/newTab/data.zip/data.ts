import * as Msal from "msal";
import {GetAccessToken} from './token';
import axios from "axios";
 
export async function GetBadges() {
 
    var datas;
 
    let token = await GetAccessToken();
    const userDetails = axios.get("https://m365x602459.sharepoint.com/sites/iAppreciate/_api/web/lists/getbytitle('badges')/items", {
        headers: {
            "content-type": "application/json",
            "Authorization": "Bearer "+ token
        }
    }).then(function (response) {
        // console.log(response);
        // console.log(response.data);
        return response.data.value;
    }).catch(function (error) {
        console.log(error);
    });
 
    return userDetails
}
