// import { MsalClientSetup  } from "@pnp/msaljsclient";
import { MsalClient } from "@pnp/msaljsclient";



 
export async function GetAccessToken() {
 
            const client = new MsalClient({
                auth: {
                    authority: "https://login.microsoftonline.com/common",
                    clientId: "5efb52f6-ed8b-4af0-b7b4-8eb44cb1e8a8",
                    redirectUri: "https://158af11c44d6.ngrok.io/newTab/",
                },
            });
 
            const token = await client.getToken(["https://m365x602459.sharepoint.com/.default"]);
            // console.log(token);
 
            return token;
}